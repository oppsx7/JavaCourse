package bg.sofia.uni.fmi.mjt.wish.list;

public class WishListClientTest {
}
